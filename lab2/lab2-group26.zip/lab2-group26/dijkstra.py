import topo
from collections import defaultdict

def default_dict():
		return defaultdict(default_dict)

def dijkstra_shortest_path(servers, switches, report=False):
	# only use the connected servers and switches in the network
	servers = [server for server in servers if len(server.edges) > 0]
	switches = [switch for switch in switches if len(switch.edges) > 0]

	# create two lists of visited and unvisited servers
	visited = []
	unvisited = [server for server in servers] + [switch for switch in switches]

	
	dijksta_table = default_dict()

	# add servers and switches to the dijkstra table
	for vertex in unvisited:
		dijksta_table[vertex.id][vertex.type]['dist'] = float('inf')
		dijksta_table[vertex.id][vertex.type]['prev']['type'] = None
		dijksta_table[vertex.id][vertex.type]['prev']['id'] = None

	# set starting point and set its distance to the starting point to zero
	starting_point = unvisited[0]
	current_vertex = starting_point
	dijksta_table[starting_point.id][starting_point.type]['dist'] = 0
	

	# create a table with, for each server, its distance from the starting point and its previous vertex
	while unvisited:

		for edge in current_vertex.edges:

			# left node has same id but is of a different type (switch and server)
			if edge.lnode.id == current_vertex.id:
				if not edge.lnode.type == current_vertex.type:
					neighbor = edge.lnode
			else:
				neighbor = edge.lnode

			# right node has same id but different type (switch and server)
			if edge.rnode.id == current_vertex.id:
				if not edge.rnode.type == current_vertex.type:
					neighbor = edge.rnode
			else:
				neighbor = edge.rnode

			if neighbor in unvisited:

				distance = dijksta_table[current_vertex.id][current_vertex.type]['dist'] + 1

				if distance < dijksta_table[neighbor.id][neighbor.type]['dist']:

					dijksta_table[neighbor.id][neighbor.type]['dist'] = distance
					dijksta_table[neighbor.id][neighbor.type]['prev'] = {'type' : current_vertex.type, 'id' : current_vertex.id}

		visited.append(current_vertex)
		unvisited.remove(current_vertex)

		# vertex with the lowest distance in the unvisited list becomes next current vertex
		shortest_dist = float('inf')
		new_vertex = None
		if unvisited:
			for vertex in unvisited:

				distance = dijksta_table[vertex.id][vertex.type]['dist']
				# print(distance)

				if distance <= shortest_dist:
					# print(distance, shortest_dist)
					shortest_dist = distance

					new_vertex = vertex
			
			

			current_vertex = new_vertex

		# stop if there are no more servers in the unvisited list
		if not any([True for vertex in unvisited if vertex.type == 'server']):
			break
	
	# print Dijkstra Table if requested
	if report:
		print()
		print('----------------------------------------------------------')
		print('|                    Dijkstra Table                      |')
		print('----------------------------------------------------------')
		print('|   Server/Switch  |     Distance    |   Previous Node   |')
		print('----------------------------------------------------------')

	
		for target_type in ['server', 'switch']:
			for id in dijksta_table:
				for type in dijksta_table[id]:
					if type == target_type:
						dist = dijksta_table[id][type]['dist']
						
						prev_type = dijksta_table[id][type]['prev']['type']
						prev_id = dijksta_table[id][type]['prev']['id']

						previous_str = prev_type + ' ' + str(prev_id).ljust(6) if not prev_type == None else '  ' + str(None).ljust(11)

						print(f"|     {type} {id}     |   {dist:6}        |     {previous_str} |")

			print('----------------------------------------------------------')

		print()

	return dijksta_table

